/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.regloginsys2;
//these lines are for importing required classes in my program
import java.util.ArrayList;//lets us read the input from the keyboard
import java.util.Scanner;//this line allows us to store users data
import java.util.regex.Pattern;//this enables us to check patterns like password and cellphone

public class Regloginsys2 {
 //scanner is used to read user input from keyboard  
    static Scanner scanner = new Scanner(System.in);
    //this list will store all registred users
    static ArrayList<User> users = new ArrayList<>();
    //this will store the login status message to show after login
    static User currentUser = null;

    public static void main(String[] args) {
          //call the registerUser method and save it as return message
        String regResult = registerUser();
         //print the registration message
        System.out.println(regResult);

        if (regResult.contains("Registration complete")) {
            boolean loggedIn = loginUser();
            System.out.println(returnLoginStatus(loggedIn));
              //call the LoginUser method to login the user
        }
    }

    /**
     //Inner class for storing user information
     */
      //this inner class stores user information like name, phone number, passowrd
    static class User {
        String firstName;
        String lastName;
        String phoneNumber;
        String username;
        String password;

        User(String firstName, String lastName, String phoneNumber, String username, String password) {
            this.firstName = firstName;
            this.lastName = lastName;
            this.phoneNumber = phoneNumber;
            this.username = username;
            this.password = password;
             //constructor to save under information when new user is created
        }
    }
    //this method checks if the username has an underscore and is 5 character or less

    // -------------------------------------------------------------------------
    // VALIDATION METHODS
    // -------------------------------------------------------------------------

    /**
     //Checks if username is valid
     */
        //this method checks if the password is strong using a pattern(regex)
    public static boolean checkUserName(String username) {
        return username.contains("_") && username.length() <= 5;
    }

    /**
     //Checks if password meets complexity requirements
     */
    public static boolean checkPasswordComplexity(String password) {
        String pattern = "^(?=.*[A-Z])(?=.*\\d)(?=.*[!@#$%^&*()_+\\-=\\[\\]{};':\"\\\\|,.<>\\/?]).{8,}$";
        return Pattern.matches(pattern, password);
    }

    /**
     //Checks if cell number is valid South African format
     */
    public static boolean checkCellPhoneNumber(String phoneNumber) {
        String pattern = "^\\+27\\d{9}$"; // Must start with +27 and 9 more digits
        return Pattern.matches(pattern, phoneNumber);
    }

    /**
     //Handles registration process
     */
    public static String registerUser() {
        System.out.println("\n--- User Registration ---");

        System.out.print("Enter First name: ");
        String firstName = scanner.nextLine();

        System.out.print("Enter Last name: ");
        String lastName = scanner.nextLine();

        // Username validation
        String username;
        while (true) {
            System.out.print("Enter Username (must have '_' and max 5 chars): ");
            username = scanner.nextLine();
            if (!checkUserName(username)) {
                System.out.println("Invalid username. Must contain '_' and be 5 chars or less.");
            } else {
                System.out.println("Username successfully captured.");
                break;
            }
        }

        // Password validation
        String password;
        while (true) {
            System.out.print("Enter Password (min 8 chars, incl. capital, number, special char): ");
            password = scanner.nextLine();
            if (!checkPasswordComplexity(password)) {
                System.out.println("Invalid password. Must be at least 8 chars, include a capital letter, number, and special character.");
            } else {
                System.out.println("Password successfully captured.");
                break;
            }
        }

        // Phone number validation
        String phoneNumber;
        while (true) {
            System.out.print("Enter South African Cell Phone Number (e.g., +27831234567): ");
            phoneNumber = scanner.nextLine();
            if (!checkCellPhoneNumber(phoneNumber)) {
                System.out.println("Invalid phone number. Must start with +27 and contain 9 more digits.");
            } else {
                System.out.println("Cell phone number successfully added.");
                break;
            }
        }

        // Save user
        users.add(new User(firstName, lastName, phoneNumber, username, password));
        return "Registration complete! You can now log in.";
    }

    /**
     //Verifies login credentials
     */
    public static boolean loginUser() {
        System.out.println("\n--- User Login ---");

        System.out.print("Enter Username: ");
        String usernameInput = scanner.nextLine();

        System.out.print("Enter Password: ");
        String passwordInput = scanner.nextLine();

        for (User user : users) {
            if (user.username.equals(usernameInput) && user.password.equals(passwordInput)) {
                currentUser = user;
                return true;
            }
        }
        return false;
    }

    /**
     //Returns login message
     */
    public static String returnLoginStatus(boolean loggedIn) {
        if (loggedIn) {
            return "Welcome " + currentUser.firstName + " " + currentUser.lastName + ", it is great to see you again.";
        } else {
            return "Username or password incorrect, please try again.";
        }
    }
}
  